Examples for text and images on a 128x64 OLED using the DigisparkOLED library
