Using the DigisparkOLED library to display ADC readings as text on the 128x64 OLED
