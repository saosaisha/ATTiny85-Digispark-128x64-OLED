Displaying an image stored in memory on a 128x64 OLED using the DigisparkOLED library
