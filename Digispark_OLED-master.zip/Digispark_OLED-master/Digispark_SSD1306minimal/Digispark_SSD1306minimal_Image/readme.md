Display image from memory on 128x64 OLED
