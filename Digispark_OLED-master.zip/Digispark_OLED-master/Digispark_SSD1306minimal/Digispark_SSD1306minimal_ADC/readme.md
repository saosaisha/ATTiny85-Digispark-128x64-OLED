Read ADC and display text on 128x64 OLED
