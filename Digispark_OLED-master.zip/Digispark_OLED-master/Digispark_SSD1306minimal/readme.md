Digispark OLED 128x64 text and image display using less memory with SSD1306minimal
